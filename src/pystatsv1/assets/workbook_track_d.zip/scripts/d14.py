# SPDX-License-Identifier: MIT
"""Track D convenience wrapper.

Runs: business_ch14_regression_driver_analysis.py

Use either:
  pystatsv1 workbook run d14
or:
  pystatsv1 workbook run business_ch14_regression_driver_analysis
"""

from __future__ import annotations

from scripts.business_ch14_regression_driver_analysis import main


if __name__ == "__main__":
    main()
