# SPDX-License-Identifier: MIT
"""Track D convenience wrapper.

Runs: business_ch11_sampling_estimation_audit_controls.py

Use either:
  pystatsv1 workbook run d11
or:
  pystatsv1 workbook run business_ch11_sampling_estimation_audit_controls
"""

from __future__ import annotations

from scripts.business_ch11_sampling_estimation_audit_controls import main


if __name__ == "__main__":
    main()
