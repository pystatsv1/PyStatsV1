# SPDX-License-Identifier: MIT
"""Track D convenience wrapper.

Runs: business_ch22_financial_statement_analysis_toolkit.py

Use either:
  pystatsv1 workbook run d22
or:
  pystatsv1 workbook run business_ch22_financial_statement_analysis_toolkit
"""

from __future__ import annotations

from scripts.business_ch22_financial_statement_analysis_toolkit import main


if __name__ == "__main__":
    main()
