# SPDX-License-Identifier: MIT
"""Track D convenience wrapper.

Runs: business_ch08_descriptive_statistics_financial_performance.py

Use either:
  pystatsv1 workbook run d08
or:
  pystatsv1 workbook run business_ch08_descriptive_statistics_financial_performance
"""

from __future__ import annotations

from scripts.business_ch08_descriptive_statistics_financial_performance import main


if __name__ == "__main__":
    main()
