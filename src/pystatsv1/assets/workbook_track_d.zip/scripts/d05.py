# SPDX-License-Identifier: MIT
"""Track D convenience wrapper.

Runs: business_ch05_liabilities_payroll_taxes_equity.py

Use either:
  pystatsv1 workbook run d05
or:
  pystatsv1 workbook run business_ch05_liabilities_payroll_taxes_equity
"""

from __future__ import annotations

from scripts.business_ch05_liabilities_payroll_taxes_equity import main


if __name__ == "__main__":
    main()
