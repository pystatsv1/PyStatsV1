# SPDX-License-Identifier: MIT
"""Track D convenience wrapper.

Runs: business_ch12_hypothesis_testing_decisions.py

Use either:
  pystatsv1 workbook run d12
or:
  pystatsv1 workbook run business_ch12_hypothesis_testing_decisions
"""

from __future__ import annotations

from scripts.business_ch12_hypothesis_testing_decisions import main


if __name__ == "__main__":
    main()
