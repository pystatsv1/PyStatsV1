# SPDX-License-Identifier: MIT
"""Track D convenience wrapper.

Runs: business_ch17_revenue_forecasting_segmentation_drivers.py

Use either:
  pystatsv1 workbook run d17
or:
  pystatsv1 workbook run business_ch17_revenue_forecasting_segmentation_drivers
"""

from __future__ import annotations

from scripts.business_ch17_revenue_forecasting_segmentation_drivers import main


if __name__ == "__main__":
    main()
