# SPDX-License-Identifier: MIT
"""Track D convenience wrapper.

Runs: business_ch23_communicating_results_governance.py

Use either:
  pystatsv1 workbook run d23
or:
  pystatsv1 workbook run business_ch23_communicating_results_governance
"""

from __future__ import annotations

from scripts.business_ch23_communicating_results_governance import main


if __name__ == "__main__":
    main()
