# SPDX-License-Identifier: MIT
"""Track D convenience wrapper.

Runs: business_ch18_expense_forecasting_fixed_variable_step_payroll.py

Use either:
  pystatsv1 workbook run d18
or:
  pystatsv1 workbook run business_ch18_expense_forecasting_fixed_variable_step_payroll
"""

from __future__ import annotations

from scripts.business_ch18_expense_forecasting_fixed_variable_step_payroll import main


if __name__ == "__main__":
    main()
