# PyStatsV1 Workbook Starter (Track C)

This folder was created by:

    pystatsv1 workbook init

## Recommended workflow

1) Activate your virtual environment (required).

2) Run a chapter script:

    python scripts/psych_ch10_problem_set.py

3) Check your work with tests:

    pytest -q

## Make targets (optional)

If you have `make` available (Git Bash on Windows usually does), you can use:

    make psych-ch10-problems
    make test-ch10
    make test

Tip: Start with Chapter 10, then move forward in order.
