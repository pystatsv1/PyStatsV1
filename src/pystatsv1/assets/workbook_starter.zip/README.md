# PyStatsV1 Workbook Starter

This folder is a **beginner-friendly stats workbook**.
It works on **Linux, macOS, and Windows**, and it does **not** require `make`.

## 0) Setup

1. Create a Python virtual environment.
2. Install PyStatsV1:

```bash
pip install pystatsv1
```

## 1) Run → Inspect → Check

### Run a chapter script

```bash
pystatsv1 workbook run ch10
```

### Inspect outputs

Look at what the script prints and any files it writes under `outputs/`.

### Check your work

```bash
pystatsv1 workbook check ch10
```

## 2) Case study: Study Habits (recommended)

A small, realistic dataset + a short story that carries across scripts.

```bash
pystatsv1 workbook run study_habits_01_explore
pystatsv1 workbook run study_habits_02_anova
pystatsv1 workbook check study_habits
```

## 3) My Own Data

Start with the template CSV:

- `data/my_data.csv`
- scaffold script: `scripts/my_data_01_explore.py`

```bash
pystatsv1 workbook run my_data_01_explore
pystatsv1 workbook check my_data
```

If you want to run the script directly (to pass arguments):

```bash
python scripts/my_data_01_explore.py --csv data/my_data.csv --outdir outputs/my_data
```

---

If you ever get stuck, see the Workbook docs on ReadTheDocs.
